module.exports = {
	mongoURL: "mongodb+srv://mahfuz:<password>@cluster01.m4msb.mongodb.net/<dbname>?retryWrites=true&w=majority"
}
